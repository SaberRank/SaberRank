using SnoreSaber.Features.Live.Compete.Domain;
using SnoreSaber.Features.Live.Compete.Packets;
using SnoreSaber.Live.V1;
using System;

namespace SnoreSaber.Features.Live.Compete.Packets.Handlers {
    internal sealed class CloseRoomCommandHandler : ILudusServerCommandHandler {
        public LudusCommandType Type => LudusCommandType.LudusCommandTypeCloseRoom;

        public void Handle(ILudusServerCommandSession session, ServerCommand command) {
            CompeteRoom room = session.TournamentRoom;
            if (room == null) {
                return;
            }

            if (!string.IsNullOrEmpty(command.MatchId) && !string.Equals(command.MatchId, room.Id, StringComparison.Ordinal)) {
                return;
            }

            session.NotifyStatusChanged("Room closed.");
            session.CloseTournamentRoom();
            Plugin.Log.Info($"Ludus: Closed room {room.Id}.");
        }
    }
}
