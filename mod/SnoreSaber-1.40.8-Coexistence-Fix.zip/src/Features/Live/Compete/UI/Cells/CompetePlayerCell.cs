using SnoreSaber.Features.Live.Compete.Domain;
using SnoreSaber.Core.Presentation;
using HMUI;
using BeatSaberMarkupLanguage.Attributes;
using System;

namespace SnoreSaber.Features.Live.Compete.UI.Cells {
    internal class CompetePlayerCell : CompeteListRowCell {
        private const string DefaultAvatar = "SnoreSaber.Resources.user.png";

        private CompetePlayer _player;
        private readonly Action<string, string> _profileClicked;
        private readonly SnoreSaberUIMaterials _materials;
        private string _key;

        [UIValue("avatar-url")]
        private string avatarUrl => string.IsNullOrEmpty(_player.AvatarUrl) ? DefaultAvatar : _player.AvatarUrl;

        [UIComponent("profile-image")]
        private readonly ImageView _profileImage = null;

        internal CompetePlayerCell(CompetePlayer player, SnoreSaberUIMaterials materials, Action<string, string> profileClicked)
            : base(
                player.IsLocalPlayer ? $"{player.DisplayName} (you)" : player.DisplayName,
                player.Rank,
                player.Status) {

            _player = player;
            _materials = materials;
            _profileClicked = profileClicked;
            _key = PlayerKey(player);
        }

        internal bool Matches(CompetePlayer player) {
            return _key == PlayerKey(player);
        }

        internal void Update(CompetePlayer player) {
            string previousAvatarUrl = avatarUrl;
            _player = player;
            _key = PlayerKey(player);
            rowTitle = player.IsLocalPlayer ? $"{player.DisplayName} (you)" : player.DisplayName;
            rowDetail = player.Rank;
            rowStatus = player.Status;

            if (avatarUrl != previousAvatarUrl) {
                NotifyPropertyChanged(nameof(avatarUrl));
            }
        }

        [UIAction("profile-clicked")]
        private void ProfileClicked() {
            if (string.IsNullOrEmpty(_player.PlayerId) || _player.IsBot) {
                return;
            }

            _profileClicked?.Invoke(_player.PlayerId, _player.DisplayName);
        }

        [UIAction("#post-parse")]
        private void Parsed() {
            if (_profileImage != null && _materials != null) {
                _profileImage.material = _materials.RoundedImageMaterial;
            }
        }

        private static string PlayerKey(CompetePlayer player) {
            if (!string.IsNullOrEmpty(player.PlayerId)) {
                return player.PlayerId;
            }

            return $"{player.TeamId}:{player.Name}:{player.IsBot}";
        }
    }
}
