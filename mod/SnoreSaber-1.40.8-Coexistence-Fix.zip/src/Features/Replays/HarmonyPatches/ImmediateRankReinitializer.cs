using HarmonyLib;
using System;

namespace SnoreSaber.Features.Replays.HarmonyPatches {
    [HarmonyPatch(typeof(RelativeScoreAndImmediateRankCounter), nameof(RelativeScoreAndImmediateRankCounter.UpdateRelativeScoreAndImmediateRank))]
    internal class ImmediateRankReinitializer {
        internal static bool Prefix(RelativeScoreAndImmediateRankCounter __instance, int score, int maxPossibleScore, ref Action ___relativeScoreOrImmediateRankDidChangeEvent) {
            if (!ReplayStateRegistry.IsModernPlaybackEnabled || score != 0 || maxPossibleScore != 0) {
                return true;
            }

            __instance.relativeScore = 1f;
            __instance.immediateRank = RankModel.Rank.SS;
            ___relativeScoreOrImmediateRankDidChangeEvent?.Invoke();
            return false;
        }
    }
}
