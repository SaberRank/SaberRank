using HarmonyLib;
using IPA.Loader;
using LeaderboardCore.Models;
using SnoreSaber.Features.Leaderboards.Domain;
using System.Collections.Generic;
using System.Reflection;
using HiveVersion = Hive.Versioning.Version;

namespace SnoreSaber.Features.Leaderboards.Adapters.LeaderboardCore {
    [HarmonyPatch]
    internal static class LegacyLeaderboardCoreDefaultLeaderboardPatch {
        private const string NavigationButtonsType = "LeaderboardCore.UI.ViewControllers.LeaderboardNavigationButtonsController";
        private const string LegacySnoreSaberLeaderboardCoreType = "LeaderboardCore.Models.SnoreSaberCustomLeaderboard";
        private static readonly HiveVersion MaxPatchedLeaderboardCoreVersion = new HiveVersion("1.7.0");

        private static bool Prepare() => ShouldPatchLegacyLeaderboardCore() && TargetShowDefaultLeaderboard() != null;

        private static MethodBase TargetMethod() => TargetShowDefaultLeaderboard();

        private static MethodBase TargetShowDefaultLeaderboard() {
            System.Type type = typeof(CustomLeaderboard).Assembly.GetType(NavigationButtonsType);
            if (type == null) {
                return null;
            }

            return AccessTools.PropertyGetter(type, "ShowDefaultLeaderboard");
        }

        private static void Postfix(object __instance, ref bool __result) {
            if (!__result || !HasCustomLeaderboard(__instance) || !SnoreSaberBeatmapKey.IsCustomLevelId(__instance.GetSelectedLevelId())) {
                return;
            }

            __result = false;
        }

        private static bool ShouldPatchLegacyLeaderboardCore() {
            PluginMetadata metadata = PluginManager.GetPluginFromId("LeaderboardCore");
            return metadata != null
                && metadata.HVersion.CompareTo(MaxPatchedLeaderboardCoreVersion) <= 0
                && typeof(CustomLeaderboard).Assembly.GetType(LegacySnoreSaberLeaderboardCoreType) != null;
        }

        private static bool HasCustomLeaderboard(object instance) {
            var leaderboards = Traverse.Create(instance).Field("orderedCustomLeaderboards").GetValue<List<CustomLeaderboard>>();
            return leaderboards != null && leaderboards.Count > 0;
        }

    }
}
