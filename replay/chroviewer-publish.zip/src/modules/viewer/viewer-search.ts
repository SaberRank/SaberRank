import * as z from 'zod/mini';

import type { DifficultyRank } from '../../core/beatmap/info';
import type { SharedViewerSettings } from '../../core/share-link';
import { viewerSettingsPatchSchema } from '../../core/viewer-settings';

export type ViewerShareSource =
  | { type: 'map'; mapKey: string; difficulty?: DifficultyRank; characteristic?: string }
  | { type: 'replay'; replayUrl: string }
  | { type: 'score'; scoreId: string }
  | { type: 'score-bl'; scoreId: string }
  | { type: 'live'; playerId: string; tournamentId?: string; roomId?: string; matchId?: string };

const searchIdentifierSchema = z.union([z.string(), z.pipe(z.int(), z.transform(String))]);
const mapKeySchema = z.pipe(
  searchIdentifierSchema.check(z.regex(/^[0-9a-f]+$/i)),
  z.transform((value) => value.toLowerCase()),
);
const scoreIdSchema = searchIdentifierSchema.check(z.regex(/^\d+$/));
const loopbackHostnames = new Set(['localhost', '127.0.0.1', '[::1]']);
const remoteSourceUrlSchema = z.pipe(
  z.string().check(z.maxLength(4096)),
  z.url({ protocol: /^https?$/ }).check(
    z.refine((value) => {
      if (!URL.canParse(value)) return false;
      const url = new URL(value);
      return url.protocol === 'https:' || loopbackHostnames.has(url.hostname);
    }),
  ),
);
const mapSourceSchema = z.union([mapKeySchema, remoteSourceUrlSchema]);
const nonnegativeNumberSchema = z.number().check(z.nonnegative());
const difficultyRankSchema = z.union([z.literal(1), z.literal(3), z.literal(5), z.literal(7), z.literal(9)]);
const characteristicSchema = z.string().check(z.minLength(1), z.maxLength(128));
const liveIdSchema = searchIdentifierSchema.check(z.minLength(1), z.maxLength(128));
const livePlayerIdSchema = liveIdSchema.check(z.regex(/^\d+$/));

export const viewerSearchSchema = z.pipe(
  z.object({
    party: z.catch(z.optional(livePlayerIdSchema), undefined),
    map: z.catch(z.optional(mapSourceSchema), undefined),
    replayUrl: z.catch(z.optional(remoteSourceUrlSchema), undefined),
    scoreId: z.catch(z.optional(scoreIdSchema), undefined),
    scoreIdBL: z.catch(z.optional(scoreIdSchema), undefined),
    difficulty: z.catch(z.optional(difficultyRankSchema), undefined),
    characteristic: z.catch(z.optional(characteristicSchema), undefined),
    beat: z.catch(z.optional(nonnegativeNumberSchema), undefined),
    autoplay: z.catch(z.optional(z.boolean()), undefined),
    lightshow: z.catch(z.optional(z.literal('full-lightshow')), undefined),
    settings: z.catch(z.optional(viewerSettingsPatchSchema), undefined),
    playerId: z.catch(z.optional(livePlayerIdSchema), undefined),
    tournamentId: z.catch(z.optional(liveIdSchema), undefined),
    roomId: z.catch(z.optional(liveIdSchema), undefined),
    matchId: z.catch(z.optional(liveIdSchema), undefined),
    watcherPlayerId: z.catch(z.optional(livePlayerIdSchema), undefined),
    authToken: z.catch(z.optional(z.string().check(z.minLength(1), z.maxLength(4096))), undefined),
  }),
  z.transform((search) => {
    if (search.party !== undefined) {
      return {
        ...search,
        map: undefined,
        replayUrl: undefined,
        scoreId: undefined,
        scoreIdBL: undefined,
        difficulty: undefined,
        characteristic: undefined,
        beat: undefined,
        autoplay: undefined,
        playerId: undefined,
        tournamentId: undefined,
        roomId: undefined,
        matchId: undefined,
        watcherPlayerId: undefined,
        authToken: undefined,
      };
    }
    if (search.playerId !== undefined) {
      return {
        ...search,
        map: undefined,
        replayUrl: undefined,
        scoreId: undefined,
        scoreIdBL: undefined,
        difficulty: undefined,
        characteristic: undefined,
        beat: undefined,
      };
    }
    if (search.replayUrl !== undefined)
      return {
        ...search,
        map: undefined,
        scoreId: undefined,
        scoreIdBL: undefined,
        difficulty: undefined,
        characteristic: undefined,
      };
    if (search.scoreId !== undefined)
      return { ...search, map: undefined, scoreIdBL: undefined, difficulty: undefined, characteristic: undefined };
    if (search.scoreIdBL !== undefined)
      return { ...search, map: undefined, scoreId: undefined, difficulty: undefined, characteristic: undefined };
    return search;
  }),
);

export type ViewerSearch = z.infer<typeof viewerSearchSchema>;

export function isRemoteSourceUrl(value: string) {
  return remoteSourceUrlSchema.safeParse(value).success;
}

export function viewerSearchForShare(
  source: ViewerShareSource,
  beat: number | undefined,
  settings?: SharedViewerSettings,
  lightshow?: 'full-lightshow',
): ViewerSearch {
  if (source.type === 'live') {
    return {
      playerId: source.playerId,
      tournamentId: source.tournamentId,
      roomId: source.roomId,
      matchId: source.matchId,
      settings,
      lightshow,
    };
  }
  const sharedBeat = beat !== undefined && beat > 0 ? Number(beat.toFixed(6)) : undefined;
  if (source.type === 'map') {
    return {
      map: source.mapKey,
      difficulty: source.difficulty,
      characteristic: source.characteristic,
      beat: sharedBeat,
      settings,
      lightshow,
    };
  }
  if (source.type === 'replay') return { replayUrl: source.replayUrl, beat: sharedBeat, settings, lightshow };
  if (source.type === 'score') return { scoreId: source.scoreId, beat: sharedBeat, settings, lightshow };
  return { scoreIdBL: source.scoreId, beat: sharedBeat, settings, lightshow };
}
